import firebase from "firebase"

export const firebaseConfig = {
  apiKey: "AIzaSyA72UcPTE4xJz4-b6Dn6C8RbGulCZrWSIA",
  authDomain: "storytelling-3cd88.firebaseapp.com",
  databaseURL: "https://storytelling-3cd88-default-rtdb.firebaseio.com",
  projectId: "storytelling-3cd88",
  storageBucket: "storytelling-3cd88.appspot.com",
  messagingSenderId: "202250737577",
  appId: "1:202250737577:web:509341abc5bfcc47ced6b8"
};